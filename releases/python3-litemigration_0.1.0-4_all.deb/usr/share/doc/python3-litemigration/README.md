# python3-litemigration
Simple simple module to help modify database changes in in sqlite with sql commands
